package chess;

public class myChessBoard implements ChessBoard {
    myChessPiece[][] myBoard = new myChessPiece[8][8];

    public myChessBoard(){
        resetBoard();
    }

    public myChessBoard(int test){
        for(int i = 0; i < 8; ++i){
            for(int k = 0; k < 8; ++k){
                myBoard[i][k] = null;
            }
        }
    }
    @Override
    public void addPiece(ChessPosition position, ChessPiece piece) {
        myBoard[position.getRow()][position.getColumn()] = (myChessPiece) piece;

    }

    public void delPiece(ChessPosition position) {
        myBoard[position.getRow()][position.getColumn()] = null;

    }

    @Override
    public ChessPiece getPiece(ChessPosition position) {

        return myBoard[position.getRow()][position.getColumn()];
    }

    @Override
    public void resetBoard() {
        for(int i = 0; i < 8; ++i){
            ChessGame.TeamColor color = null;
            if(i < 3){
                color = ChessGame.TeamColor.BLACK;
            }else{
                color = ChessGame.TeamColor.WHITE;
            }
            for(int k = 0; k < 8; ++k){

                if((i==0) || (i==7)){
                    //Rook, Knight, Bishop, Queen, King, Bishop, Knight, Rook
                    myBoard[i][0]= new myChessPiece.Rook(color);
                    myBoard[i][1]= new myChessPiece.Knight(color);
                    myBoard[i][2]= new myChessPiece.Bishop(color);
                    myBoard[i][3]= new myChessPiece.Queen(color);
                    myBoard[i][4]= new myChessPiece.King(color);
                    myBoard[i][5]= new myChessPiece.Bishop(color);
                    myBoard[i][6]= new myChessPiece.Knight(color);
                    myBoard[i][7]= new myChessPiece.Rook(color);
                    k = 8;
                }else if((i==1) || (i==6)){
                    myBoard[i][k] = new myChessPiece.Pawn(color);
                    // pawns
                }else{
                    myBoard[i][k] = null;
                }

            }
        }

    }

    public void displayBoard(){
        for(int i = 0; i < 8; ++i){
            for(int k = 0; k < 8; ++k){
                if(myBoard[i][k] == null){
                    System.out.print("_");
                }else{
                    System.out.print(myBoard[i][k].getMarker());
                }
                System.out.print("|");

            }
            System.out.println("");
        }
    }
}
