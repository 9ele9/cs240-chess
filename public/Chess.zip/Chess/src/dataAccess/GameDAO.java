package dataAccess;

import chess.ChessGame;
import chess_server.Game;
import chess_server.User;

import java.util.HashSet;

/**
 * Does CRUD operations on a game.
 */
public class GameDAO {
    static HashSet<Game> GameDB = new HashSet<>();
    /**
     * makes a new game, adds it to the database
     * CREATE operation
     */
    public void addGame(String name){
        Game initializeGame = new Game(name);
        if(getGameByID(initializeGame.getGameID()) != null){
            initializeGame = new Game(name);
        }
        GameDB.add(initializeGame);
    }

    /**
     * retrieves game from database
     * READ operation
     * @param ID ID of game to be retrieved
     * @return Game that is retrieved
     */
    public Game getGameByID(int ID){
        if(checkExistsByID(ID)){
            for (Game thisGame : GameDB) {
                if(thisGame.getGameID() == ID){
                    return thisGame;
                }
            }
        }
        return null;
    }

    public Game getGameByName(String name){
        if(checkExistsByName(name)){
            for (Game thisGame : GameDB) {
                if(name.equals(thisGame.getGameName())){
                    return thisGame;
                }
            }
        }
        return null;
    }

    /**
     * retrieves a list of all games in the database
     * READ operation
     * @return Collection of all games
     */
    public HashSet<Game> getAllGames(){
        return GameDB;
    }

    /**
     * sets a given player as a certain color in a given game
     * @param u User
     * @param gameID ID of game
     * @throws DataAccessException
     */
    public void pickColor(User u, ChessGame.TeamColor color, int gameID) throws DataAccessException{
        if(color == ChessGame.TeamColor.BLACK){
            getGameByID(gameID).setBlackUsername(u.getUsername());
        }else if(color == ChessGame.TeamColor.WHITE){
            getGameByID(gameID).setWhiteUsername(u.getUsername());
        }

    }

    /**
     * deletes a given game from the database
     * DELETE operation
     * @param toDelete Game that is being deleted
     * @throws DataAccessException
     */
    public void deleteGame(Game toDelete) throws DataAccessException{
    }

    /**
     * updates a given game
     * UPDATE operation
     * @param toEdit Game that is being updated
     * @param newID ID to set
     * @throws DataAccessException
     */
    public void updateGame(Game toEdit, String newID) throws DataAccessException{
    }

    /**
     * deletes the whole database
     * DELETE operation
     */
    public boolean clear(){
        GameDB = new HashSet<>();
        return GameDB.isEmpty();
    }

    public boolean checkExistsByID(int query){
        for (Game thisGame : GameDB) {

            if(query == thisGame.getGameID()){
                return true;
            }
        }
        return false;
    }

    public boolean checkExistsByName(String query){
        for (Game thisGame : GameDB) {

            if(query.equals(thisGame.getGameName())){
                return true;
            }
        }
        return false;
    }

}
