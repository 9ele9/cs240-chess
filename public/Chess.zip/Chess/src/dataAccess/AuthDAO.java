package dataAccess;

import chess_server.AuthToken;

import java.util.*;
import java.util.ArrayList;

/**
 * Retrieves Authtoken data from the server.
 */
public class AuthDAO {
    static ArrayList<AuthToken> ATDB = new ArrayList<>();

    public AuthDAO(){}
    /**
     * checks given token against the token needed
     * READ operation
     */
    public boolean validate(String query){
        for (AuthToken thisToken : ATDB) {

            if(query != null && thisToken.getUsername() != null && query.equals(thisToken.getTokenValue())){
                return true;
            }
        }
        return false;
    }

    public String getUsername(String query){
        for (AuthToken thisToken : ATDB) {

            if(query != null && thisToken.getUsername() != null && query.equals(thisToken.getTokenValue())){
                return thisToken.getUsername();
            }
        }
        return "";
    }

    public void addAuth(AuthToken newToken){

        ATDB.add(newToken);
    }

    public boolean deleteAuth(String query){
        for(AuthToken d : ATDB){
            if(query.equals(d.getTokenValue())){
                ATDB.remove(d);
                return true;
            }

            //something here
        }
        return false;

    }

    public Collection<AuthToken> getAllTokens(){
        return ATDB;
    }

    public boolean clear(){
        ATDB = new ArrayList<>();
        return ATDB.isEmpty();
    }
}
