package dataAccess;

import chess_server.User;

import java.util.*;

/**
 * Does CRUD operations on users.
 */
public class UserDAO {
    public UserDAO(){}
    static ArrayList<User> UserDB = new ArrayList<>();

    /**
     * Creates a new user and adds it to the database.
     * POST operation
     * @param name Username
     * @param pass Password
     * @param mail Email
     * @return User to be created
     */
    public boolean CreateUser(String name, String pass, String mail){
        User newUser = new User(name, pass, mail);
        return UserDB.add(newUser);

    }

    /**
     * deletes a given user from the database. Requires authorization.
     * DELETE operation
     * @param u User
     * @param deleteAuth Auth token
     * @throws DataAccessException
     */
    void DeleteUser(User u, AuthDAO deleteAuth) throws DataAccessException{

    }

    /**
     * update the details of a given user. Requires authorization.
     * UPDATE operation
     * @param u User
     * @param updateAuth Auth token
     * @throws DataAccessException
     */
    void EditUser(User u, AuthDAO updateAuth) throws DataAccessException{
    }

    /**
     * Fetches a specified user from the database.
     * READ operation
     * @param name User
     */
    public User getUser(String name){
        for (User thisUser : UserDB) {

            if(name != null && thisUser.getUsername() != null && (name.equals(thisUser.getUsername()))){
                return thisUser;
            }
        }
        return null;
    }

    public boolean checkExists(String query){
        for (User thisUser : UserDB) {

            if(query != null && thisUser.getUsername() != null && (query.equals(thisUser.getUsername()))){
                return true;
            }
        }
        return false;
    }

    public boolean samePass(String query){
        for (User thisUser : UserDB) {

            if(query != null && thisUser.getPassword() != null && (query.equals(thisUser.getPassword()))){
                return true;
            }
        }
        return false;
    }

    /**
     * Gets all users from the database.
     * READ operation
     * @return List of all users.
     * @throws DataAccessException
     */
    public Collection<User> getAllUsers(){
        return UserDB;
    }
    public boolean clear(){
        /*for (User thisUser : UserDB) {
            UserDB.remove(thisUser);
        }*/
        UserDB = new ArrayList<>();
        return UserDB.isEmpty();
    }

}
