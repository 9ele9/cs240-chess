package service;

import dataAccess.AuthDAO;
import dataAccess.GameDAO;
import service.responses.CreateGameResponse;
import service.responses.ListGameResponse;

/**
 * Gives a list of all games.
 */
public class ListGamesService {
    /**
     * Gives a list of all games.
     */
    public ListGameResponse listGames(String token){
        if(token.isEmpty()){
            return new ListGameResponse("Error: description", 500);
        }
        AuthDAO checkLoggedIn = new AuthDAO();
        if(!checkLoggedIn.validate(token)){
            return new ListGameResponse("Error: unauthorized", 401);
        }else{
            GameDAO newGame = new GameDAO();
            return new ListGameResponse(newGame.getAllGames());
        }

    }
}
