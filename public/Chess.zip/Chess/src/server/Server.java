package server;
import chess_server.AuthToken;
import chess_server.Game;
import chess_server.User;
import com.google.gson.Gson;
import dataAccess.AuthDAO;
import dataAccess.UserDAO;
import spark.*;
import java.util.*;
import server.handlers.*;
public class Server {
    private ArrayList<String> names = new ArrayList<>();
    public static void main(String[] args) {
        new Server().run();
    }

    private void run() {
        // Specify the port you want the server to listen on
        Spark.port(8080);

        // Register a directory for hosting static files
        Spark.externalStaticFileLocation("web");

        // Register handlers for each endpoint using the method reference syntax
        RegisterHandler register = new RegisterHandler();
        ClearHandler clear = new ClearHandler();
        LoginHandler login = new LoginHandler();
        LogoutHandler logout = new LogoutHandler();
        CreateGameHandler createGame = new CreateGameHandler();
        ListGamesHandler listGames = new ListGamesHandler();
        JoinGamesHandler joinGame = new JoinGamesHandler();

        Spark.post("/echo", this::echoBody);

        Spark.post("/name/:name", this::addName);
        Spark.get("/user", this::listNames);
        Spark.get("/token", this::listToken);
        Spark.delete("/name/:name", this::deleteName);

    }

    private Object addName(Request req, Response res) {
        names.add(req.params(":name"));
        return listNames(req, res);
    }

    private Object listNames(Request req, Response res) {
        res.type("application/json");
        UserDAO test = new UserDAO();
        return new Gson().toJson(Map.of("name", test.getAllUsers()));
    }

    private Object listToken(Request req, Response res) {
        res.type("application/json");
        AuthDAO test = new AuthDAO();
        return new Gson().toJson(Map.of("tokens", test.getAllTokens()));
    }

    private Object deleteName(Request req, Response res) {
        names.remove(req.params(":name"));
        return listNames(req, res);
    }

    private Object echoBody(Request req, Response res) {
        var bodyObj = getBody(req, Map.class);

        res.type("application/json");
        return new Gson().toJson(bodyObj);
    }

    private static <T> T getBody(Request request, Class<T> clazz) {
        var body = new Gson().fromJson(request.body(), clazz);
        if (body == null) {
            throw new RuntimeException("missing required body");
        }
        return body;
    }
}
